var fs = require('fs'),
	http = require('http'),
	events = require('events'),
	osc = require('node-osc-master'),
	dgram = require('dgram'); //for UDP; see www.hacksparrow.com/node-js-udp-server-and-client-example.html

var theHead,
	theTail;

var theUsedPorts={};

// what if two applications ask for a port at the same time, get it reserved, and then both respond saying they want it?
	// for this, i need to keep track of how many requests each IP has made, so that i can make sure the ports offered don't overlap
	// for that, i need to add an "IP-offset" property to my records object that is always different

fs.readFile(__dirname+"/head.html", 'utf8', function (err,data) {
	if (err) return console.log(err);
	theHead=data;
});

fs.readFile(__dirname+"/tail.html", 'utf8', function (err,data) {
	if (err) return console.log(err);
	theTail=data;
});

http.createServer(function (req, res) { //offer an unused port, communicating over a TCP connection
		var theIncomingIPAddress=req.connection.remoteAddress;
		if(theIncomingIPAddress=="::1")theIncomingIPAddress="localhost";

		/* offer a port depending what's available at the current IP address */
		var theOfferedPort=5000;
		if(theIncomingIPAddress in theUsedPorts){
			var theArrayOfPorts=theUsedPorts[theIncomingIPAddress];
			var theLength=theArrayOfPorts.length;
			for(var i=0;i<theLength;i++){
				if(theArrayOfPorts[i]==theOfferedPort){
					theOfferedPort++;
				}else{
					break;
				}
			}
		}

		res.writeHead(200, {'Content-Type': 'text/html'});
		res.write(theHead+"window.max.outlet('"+theIncomingIPAddress+" "+theOfferedPort+"');"+theTail); //serve Max its own address and proposed port
		res.end(); //Some browsers load the webpage twice for the hell of it under some conditions.
}).listen(8888);

var logisticsServer = dgram.createSocket('udp4'); //This server handles the logistics of the bots starting and stopping.
	logisticsServer.on('listening', function () {
		var address = logisticsServer.address();
		console.log('Logistics server listening on ' + address.address + ":" + address.port+".");
	});
	logisticsServer.on('message', function (message, remote) {
		theMessage=message.toString('utf8').split(" ");
		theTypeOfMessage=theMessage[0];

		switch(theTypeOfMessage){
			case "/initial":
				var theIncomingPortNumber=parseInt(theMessage.pop(),10),
					theIncomingIPAddress=theMessage.pop();

				/* add the indicated port to the record */
				if(theIncomingIPAddress in theUsedPorts){
					var theArrayOfPorts=theUsedPorts[theIncomingIPAddress];
					var theMaxInsertionIndex=theArrayOfPorts.length;
					var theIndexToInsertAt=0;
					while(theIndexToInsertAt<theMaxInsertionIndex&&theArrayOfPorts[theIndexToInsertAt]<theIncomingPortNumber){
						theIndexToInsertAt++;
					}
					theArrayOfPorts.splice(theIndexToInsertAt,0,theIncomingPortNumber);
				}else{
					theUsedPorts[theIncomingIPAddress]=[theIncomingPortNumber];
				}

				break;
			case "/final":
				var theIncomingPortNumber=parseInt(theMessage.pop(),10),
					theIncomingIPAddress=theMessage.pop();

				/* subtract the indicated port from the record */
				var theArrayOfPorts=theUsedPorts[theIncomingIPAddress];
				for(var i=theArrayOfPorts.length-1;i>=0;i--){
					if(theArrayOfPorts[i]==theIncomingPortNumber){
						theArrayOfPorts.splice(i,1);
						break;
					}
				}

				break;
			default:
				console.log("I don't understand this following message: '"+theMessage+"'.");
				break;
		}

		console.log(theUsedPorts);
	});
	logisticsServer.bind(33333,'127.0.0.1');

var broadcastServer = dgram.createSocket('udp4'); //This server handles the logistics of the bots starting and stopping.
	broadcastServer.on('listening', function () {
		var address = broadcastServer.address();
		console.log('Broadcast server listening on ' + address.address + ":" + address.port+".");
	});
	broadcastServer.on('message', function (message, remote) {
		theMessage=message.toString('utf8').split(" ");
		theTypeOfMessage=theMessage.splice(0,1);

		switch(String(theTypeOfMessage)){ //Cast to string object so the switch statement recognizes it.
			case "/broadcast":
				var networkAddress,
					theArrayOfPorts;

				for(networkAddress in theUsedPorts){
					theArrayOfPorts=theUsedPorts[networkAddress];
					for (const givenPort of theArrayOfPorts) {
						//var client = new osc.Client('127.0.0.1', givenPort);

						var client = new osc.Client(networkAddress, givenPort);

						client.send('/broadcast',theMessage.join(" "), function () { //Might want to use the OSC library for receiving too?  That way might not need formatting on Max end.
							//client.kill();
							/*	
								This was causing an error, and I don't see why it was needed, so I commented it out.
								But in future I might want to try and catch it.
								See https://nodejs.org/api/dgram.html.
							*/
						});
					}
				}
			
				break;
			default:
				console.log("I didn't understand this tag: "+theTypeOfMessage+"."); //fix this error message!
				break;
		}
	});
	broadcastServer.bind(33334,'127.0.0.1');