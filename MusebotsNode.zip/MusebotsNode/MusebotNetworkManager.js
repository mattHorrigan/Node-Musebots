var fs = require('fs'),
	http = require('http'),
	events = require('events'),
	osc = require('node-osc-master'),
	dgram = require('dgram'); //for UDP; see www.hacksparrow.com/node-js-udp-server-and-client-example.html

var theHead="<head>\n\t<title>"
	theMiddle="</title>\n\t<script type=\"text/javascript\">",
	theTail="</script>\n</head>";

var theUsedPorts={}, //these have to be mutually exclusive categories; any port is either offered, used or available
	theOfferedPorts={};

function recordInsert(theDictionary,theKey,theNumber){ //Could maybe optimize this algorithm because i know the array is sorted.
	if(theKey in theDictionary){
		var theArray=theDictionary[theKey];
		var theMaxInsertionIndex=theArray.length,
			theIndexToInsertAt=0;
		while(theIndexToInsertAt<theMaxInsertionIndex&&theArray[theIndexToInsertAt]<theNumber){
			theIndexToInsertAt++;
		}
		theArray.splice(theIndexToInsertAt,0,theNumber);
	}else{
		theDictionary[theKey]=[theNumber];
	}
}

/* I DON'T THINK THIS IS WORKING CORRECTLY */
function recordRemove(theDictionary,theKey,theNumber){ //Works whether sorted or unsorted.
	if(theKey in theDictionary){
		var theArray=theDictionary[theKey];	
		for(var i=theArray.length-1;i>=0;i--){
			if(theArray[i]==theNumber){
				theArray.splice(i,1); //I don't break the loop here because I want robustness in case one of the bots has made duplicate requests.
			}
		}
	}
}

http.createServer(function (req, res) { //offer an unused port, communicating over a TCP connection
		var theIncomingIPAddress=req.connection.remoteAddress;
		if(theIncomingIPAddress=="::1")theIncomingIPAddress="localhost";
		
		if(!(theIncomingIPAddress in theOfferedPorts))theOfferedPorts[theIncomingIPAddress]=[];
		if(!(theIncomingIPAddress in theUsedPorts))theUsedPorts[theIncomingIPAddress]=[];

		var onConsignment=theOfferedPorts[theIncomingIPAddress];
		if(onConsignment.length>=100)onConsignment.splice(0,50);

		var reservedPorts=onConsignment.concat(theUsedPorts[theIncomingIPAddress]);

		/* offer a port depending what's available at the current IP address */
		var thePotentialOffer=5000;
		while(reservedPorts.includes(thePotentialOffer)){
			thePotentialOffer++;
		}
		theOfferedPorts[theIncomingIPAddress].push(thePotentialOffer);

		console.log("Offering a port at: "+thePotentialOffer);		

		var theNecessaryInformation=theIncomingIPAddress+" "+thePotentialOffer;

		/* includes the necessary information in the title for Max for Live to read and some javascript for Max/MSP */
		res.writeHead(200, {'Content-Type': 'text/html'});
		res.write(theHead+theNecessaryInformation+theMiddle+"window.max.outlet('"+theNecessaryInformation+"');"+theTail); //the bot its own address and offered port
		res.end(); //Some browsers load the webpage twice for the hell of it under some conditions.
}).listen(8888);

var logisticsServer = dgram.createSocket('udp4'); //This server handles the logistics of the bots starting and stopping.
	logisticsServer.on('listening', function () {
		var address = logisticsServer.address();
		console.log('Logistics server listening on ' + address.address + ":" + address.port+".");
	});
	logisticsServer.on('message', function (message, remote) {
		theMessage=message.toString('utf8').split(" ");
		theTypeOfMessage=theMessage[0];

		switch(theTypeOfMessage){ //add or subtract the indicated number from the list of active ports
			case "/initial":
				var theIncomingPortNumber=parseInt(theMessage.pop(),10),
					theIncomingIPAddress=theMessage.pop();
				recordInsert(theUsedPorts,theIncomingIPAddress,theIncomingPortNumber);
				recordRemove(theOfferedPorts,theIncomingIPAddress,theIncomingPortNumber);
				break;
			case "/final":
				var theIncomingPortNumber=parseInt(theMessage.pop(),10),
					theIncomingIPAddress=theMessage.pop();
				recordRemove(theUsedPorts,theIncomingIPAddress,theIncomingPortNumber);
				break;
			default:
				console.log("I don't understand this message: '"+theMessage+"'.");
				break;
		}

		console.log("The used ports are:");
		console.log(theUsedPorts);
	});
	logisticsServer.bind(33333,'127.0.0.1'); //I don't think will be a problem, but must make sure this won't hardcode IP from other computers' perspective.

var broadcastServer = dgram.createSocket('udp4'); //This server handles the logistics of the bots starting and stopping.
	broadcastServer.on('listening', function () {
		var address = broadcastServer.address();
		console.log('Broadcast server listening on ' + address.address + ":" + address.port+".");
	});
	broadcastServer.on('message', function (message, remote) {
		theMessage=message.toString('utf8').split(" ");
		theTypeOfMessage=theMessage.splice(0,1);

		switch(String(theTypeOfMessage)){ //Cast to string object so the switch statement recognizes it.
			case "/broadcast":
				var networkAddress,
					theArrayOfPorts;

				for(networkAddress in theUsedPorts){
					theArrayOfPorts=theUsedPorts[networkAddress];
					for (const givenPort of theArrayOfPorts) {
						//var client = new osc.Client('127.0.0.1', givenPort);

						var client = new osc.Client(networkAddress, givenPort);

						client.send('/broadcast',theMessage.join(" "), function () { //Might want to use the OSC library for receiving too?  That way might not need formatting on Max end.
							//client.kill();
							/*	
								This was causing an error, and I don't see why it was needed, so I commented it out.
								But in future I might want to try and catch it.
								See https://nodejs.org/api/dgram.html.
							*/
						});
					}
				}
			
				break;
			default:
				console.log("I didn't understand this tag: "+theTypeOfMessage+"."); //fix this error message!
				break;
		}
	});
	broadcastServer.bind(33334,'127.0.0.1');