inlets=1;
outlets=1;

//the max objects
var theInport;

function makePort(myIPAddress,portNumber){	
	if(typeof portNumber==='number' && (portNumber%1)===0){ //this deals with the possibility that the browser may load the page multiple times
		this.patcher.remove(this.patcher.getnamed("receiver")); //remove the port object if it's there
		
		theInport=this.patcher.newdefault(10,10,"udpreceive",portNumber+"");
		this.patcher.connect(theInport,0,this.patcher.getnamed("messageDistributor"),0);
	
		theInport.varname="receiver"; //assign the port object its scripting name so it can be found when the patcher gets reopened
		outlet(0,myIPAddress,portNumber);
	}
}

function off(){
	if(!max.isruntime){
		this.patcher.remove(this.patcher.getnamed("receiver"));
	}
}